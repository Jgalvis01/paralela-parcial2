/**
 * @file bsp_ puzzle_solver.cpp
 * @brief 4x4 Sliding Puzzle Solver using BFS (Breadth-First Search)
 * 
 * This program solves the 4x4 sliding puzzle by finding the minimum number
 * of moves required to reach the goal state from the initial state.
 * 
 * Goal state: "ABCDEFGHIJKLMNO#"
 * Where '#' represents the empty space.
 * 
 * @author JAPeTo
 * @version 1.6
 */
#include <iostream>
#include <queue>
#include <unordered_set>
#include <vector>

using namespace std;

const string TARGET = "ABCDEFGHIJKLMNO#";

int aStarSearch(string start){

}

int main(){
      string start;
      cin >> start;
      int result = aStarSearch(start);
      cout << result << endl;
      return 0;
}