/**
 * @file bsp_puzzle_solver.cpp
 * @brief 4x4 Sliding Puzzle Solver using BFS (Breadth-First Search)
 * 
 * This program solves the 4x4 sliding puzzle by finding the minimum number
 * of moves required to reach the goal state from the initial state.
 * 
 * Goal state: "ABCDEFGHIJKLMNO#"
 * Where '#' represents the empty space.
 * 
 * @author JAPeTo
 * @version 1.6
 */

#include <iostream>
#include <queue>
#include <unordered_set>

using namespace std;

/**
 * @brief Possible movement directions
 * 
 * Up, Down, Left, Right
 */
const int dRow[] = {-1, 1, 0, 0}; // UP, DOWN, LEFT, RIGHT
const int dCol[] = {0, 0, -1, 1};
const string MOVES[] = {"UP", "DOWN", "LEFT", "RIGHT"};

struct State{
      string board;
      int blankPos;
      int cost;
      // TODO: Complete the constructor
      State(string b, int pos, int c) : /*______________ {} */
};

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

/**
 * @brief Swaps two tiles on the board and returns new board state
 * 
 */
string swapBoardTiles(const string &currentBoard, int position1, int position2){
      string newBoard = currentBoard;
      // TODO: Swap characters at position1 and position2
      return newBoard;
}

/**
 * @brief Breadth-First Search to find shortest path to goal state
 * 
 * Explores all possible states level by level, guaranteeing the shortest path
 * will be found first due to BFS properties.
 */
int bfs(string start){
      queue<State> q;
      unordered_set<string> visited;

      // TODO: Find the initial position of the blank tile ('#')
      // int blankPos = ______________
      // q.push(State(start, blankPos, 0));
      visited.insert(start);

      while (!q.empty()){
            State current = q.front();
            q.pop();
            
            // TODO: complete the conditiional
            // Check if goal state is reached
            // If the goal state is reached, return the cost
            // if (______________) return current.cost;

            // TODO: Convert 1D position to 2D coordinates
            // FIXME: Create an auxiliar function 
            int row = ______________
            int col = ______________

            // Try all 4 possible moves
            for (int i = 0; i < 4; i++){
                  int newRow = row + dRow[i];
                  int newCol = col + dCol[i];

                  // Check if the move is within bounds
                  if (______________){
                        // TODO: Convert 2D coordinates back to 1D position
                        int newPos = ______________
                        string newBoard = swapTiles(current.board, current.blankPos, newPos);

                        // If this state hasn't been visited, add it to the queue
                        if (______________){
                              q.push(State(newBoard, newPos, current.cost + 1));
                              visited.insert(newBoard);
                        }
                  }
            }
      }
      // No solution found
      return -1;
}

// =============================================================================
// MAIN FUNCTION
// =============================================================================

int main(){
      string start;
      cin >> start;
      int result = bfs(start);
      cout << result << endl;
      return 0;
}